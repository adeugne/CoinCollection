﻿namespace CoinCollection
{
    partial class FormCoin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            labelCoinName = new Label();
            label1 = new Label();
            panel2 = new Panel();
            labelCoinPrice = new Label();
            label3 = new Label();
            panel3 = new Panel();
            labelCoinYear = new Label();
            label5 = new Label();
            panel4 = new Panel();
            labelCoinMintage = new Label();
            label7 = new Label();
            panel5 = new Panel();
            labelCoinDescription = new Label();
            label8 = new Label();
            label9 = new Label();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            labelUserName2 = new Label();
            label10 = new Label();
            label2 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(labelCoinName);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(22, 31);
            panel1.Name = "panel1";
            panel1.Size = new Size(687, 83);
            panel1.TabIndex = 3;
            // 
            // labelCoinName
            // 
            labelCoinName.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            labelCoinName.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelCoinName.Location = new Point(109, 16);
            labelCoinName.Name = "labelCoinName";
            labelCoinName.Size = new Size(556, 49);
            labelCoinName.TabIndex = 1;
            labelCoinName.Text = "Назва монети";
            labelCoinName.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 34);
            label1.Name = "label1";
            label1.Size = new Size(51, 20);
            label1.TabIndex = 0;
            label1.Text = "Назва";
            // 
            // panel2
            // 
            panel2.Controls.Add(labelCoinPrice);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(22, 145);
            panel2.Name = "panel2";
            panel2.Size = new Size(183, 172);
            panel2.TabIndex = 4;
            // 
            // labelCoinPrice
            // 
            labelCoinPrice.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            labelCoinPrice.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelCoinPrice.Location = new Point(19, 78);
            labelCoinPrice.Name = "labelCoinPrice";
            labelCoinPrice.Size = new Size(143, 52);
            labelCoinPrice.TabIndex = 1;
            labelCoinPrice.Text = "Ціна";
            labelCoinPrice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 34);
            label3.Name = "label3";
            label3.Size = new Size(41, 20);
            label3.TabIndex = 0;
            label3.Text = "Ціна";
            // 
            // panel3
            // 
            panel3.Controls.Add(labelCoinYear);
            panel3.Controls.Add(label5);
            panel3.Location = new Point(275, 145);
            panel3.Name = "panel3";
            panel3.Size = new Size(183, 172);
            panel3.TabIndex = 5;
            // 
            // labelCoinYear
            // 
            labelCoinYear.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            labelCoinYear.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelCoinYear.Location = new Point(19, 78);
            labelCoinYear.Name = "labelCoinYear";
            labelCoinYear.Size = new Size(144, 67);
            labelCoinYear.TabIndex = 1;
            labelCoinYear.Text = "Рік";
            labelCoinYear.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 34);
            label5.Name = "label5";
            label5.Size = new Size(28, 20);
            label5.TabIndex = 0;
            label5.Text = "Рік";
            // 
            // panel4
            // 
            panel4.Controls.Add(labelCoinMintage);
            panel4.Controls.Add(label7);
            panel4.Location = new Point(526, 145);
            panel4.Name = "panel4";
            panel4.Size = new Size(183, 172);
            panel4.TabIndex = 5;
            // 
            // labelCoinMintage
            // 
            labelCoinMintage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            labelCoinMintage.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelCoinMintage.Location = new Point(19, 78);
            labelCoinMintage.Name = "labelCoinMintage";
            labelCoinMintage.Size = new Size(142, 67);
            labelCoinMintage.TabIndex = 1;
            labelCoinMintage.Text = "Тираж";
            labelCoinMintage.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(19, 34);
            label7.Name = "label7";
            label7.Size = new Size(54, 20);
            label7.TabIndex = 0;
            label7.Text = "Тираж";
            // 
            // panel5
            // 
            panel5.Controls.Add(labelCoinDescription);
            panel5.Controls.Add(label8);
            panel5.Location = new Point(22, 353);
            panel5.Name = "panel5";
            panel5.Size = new Size(687, 83);
            panel5.TabIndex = 4;
            // 
            // labelCoinDescription
            // 
            labelCoinDescription.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            labelCoinDescription.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelCoinDescription.Location = new Point(109, 16);
            labelCoinDescription.Name = "labelCoinDescription";
            labelCoinDescription.Size = new Size(556, 53);
            labelCoinDescription.TabIndex = 1;
            labelCoinDescription.Text = "Опис монети";
            labelCoinDescription.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(19, 34);
            label8.Name = "label8";
            label8.Size = new Size(45, 20);
            label8.TabIndex = 0;
            label8.Text = "Опис";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label9.Location = new Point(22, 486);
            label9.Name = "label9";
            label9.Size = new Size(180, 54);
            label9.TabIndex = 2;
            label9.Text = "Власник:";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ActiveCaption;
            pictureBox1.Location = new Point(732, 31);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(259, 286);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.Location = new Point(734, 353);
            button1.Name = "button1";
            button1.Size = new Size(257, 83);
            button1.TabIndex = 7;
            button1.Text = "Закрити";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // labelUserName2
            // 
            labelUserName2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            labelUserName2.BackColor = SystemColors.ButtonHighlight;
            labelUserName2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelUserName2.Location = new Point(22, 626);
            labelUserName2.Name = "labelUserName2";
            labelUserName2.Size = new Size(212, 34);
            labelUserName2.TabIndex = 1;
            labelUserName2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(22, 595);
            label10.Name = "label10";
            label10.Size = new Size(39, 20);
            label10.TabIndex = 0;
            label10.Text = "П.І.Б";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(275, 626);
            label2.Name = "label2";
            label2.Size = new Size(212, 34);
            label2.TabIndex = 9;
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(275, 595);
            label11.Name = "label11";
            label11.Size = new Size(46, 20);
            label11.TabIndex = 8;
            label11.Text = "Email";
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label12.BackColor = SystemColors.ButtonHighlight;
            label12.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label12.Location = new Point(526, 626);
            label12.Name = "label12";
            label12.Size = new Size(212, 34);
            label12.TabIndex = 11;
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(526, 595);
            label13.Name = "label13";
            label13.Size = new Size(69, 20);
            label13.TabIndex = 10;
            label13.Text = "Телефон";
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label14.BackColor = SystemColors.ButtonHighlight;
            label14.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label14.Location = new Point(769, 626);
            label14.Name = "label14";
            label14.Size = new Size(212, 34);
            label14.TabIndex = 13;
            label14.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(769, 595);
            label15.Name = "label15";
            label15.Size = new Size(56, 20);
            label15.TabIndex = 12;
            label15.Text = "Країна";
            // 
            // FormCoin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1013, 701);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label2);
            Controls.Add(label11);
            Controls.Add(labelUserName2);
            Controls.Add(label10);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(label9);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FormCoin";
            Text = "FormCoin";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        public Label labelCoinName;
        private Label label1;
        private Panel panel2;
        public Label labelCoinPrice;
        private Label label3;
        private Panel panel3;
        public Label labelCoinYear;
        private Label label5;
        private Panel panel4;
        public Label labelCoinMintage;
        private Label label7;
        private Panel panel5;
        public Label labelCoinDescription;
        private Label label8;
        private Label label9;
        private PictureBox pictureBox1;
        private Button button1;
        public Label labelUserName2;
        private Label label10;
        public Label label2;
        private Label label11;
        public Label label12;
        private Label label13;
        public Label label14;
        private Label label15;
    }
}